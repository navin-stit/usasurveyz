
<footer style="background-color:#d6d6d6;letter-spacing:1px;padding:2px;text-align:center;color:#333;">
        <h5>
          Copyright &copy; <?php echo date('Y')?> All Rights Reserved.
        </h5>
</footer>



<!-- Javascripts --> 
<script type="text/javascript" src="../js/jquery.min.js"></script> 
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>

<script type="text/javascript" src="../js/script.js"></script>

</body>
</html>